function identifyDataTypes() {
    let inteiroInput = document.getElementById('inteiro').value;
    let decimalInput = document.getElementById('decimal').value;

    // Converte o input em número inteiro e número decimal
    let inteiro = parseInt(inteiroInput);
    let decimal = parseFloat(decimalInput);

    // Checa se os valores são realmente números após a conversão
    let inteiroType = isNaN(inteiro) ? 'não é um número' : typeof inteiro;
    let decimalType = isNaN(decimal) ? 'não é um número' : typeof decimal;

    const output = document.getElementById('output');
    output.innerHTML = `Tipo da entrada 'inteiro': ${inteiroType}<br>Tipo da entrada 'decimal': ${decimalType}`;
}
