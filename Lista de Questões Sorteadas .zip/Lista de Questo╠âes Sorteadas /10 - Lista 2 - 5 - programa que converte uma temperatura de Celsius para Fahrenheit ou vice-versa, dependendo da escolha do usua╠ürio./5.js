// script.js
document.getElementById('tempForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const temperature = parseFloat(document.getElementById('temperature').value);
    const conversion = document.getElementById('conversion').value;
    let result;

    if (conversion === 'toCelsius') {
        result = (temperature - 32) * 5 / 9;
        document.getElementById('result').innerText = `${temperature}°F é igual a ${result.toFixed(2)}°C`;
    } else if (conversion === 'toFahrenheit') {
        result = (temperature * 9 / 5) + 32;
        document.getElementById('result').innerText = `${temperature}°C é igual a ${result.toFixed(2)}°F`;
    }
});
