// script.js
document.getElementById('triangleForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const side1 = parseFloat(document.getElementById('side1').value);
    const side2 = parseFloat(document.getElementById('side2').value);
    const side3 = parseFloat(document.getElementById('side3').value);

    const resultDiv = document.getElementById('result');

    if (isNaN(side1) || isNaN(side2) || isNaN(side3) || side1 <= 0 || side2 <= 0 || side3 <= 0) {
        resultDiv.innerText = 'Por favor, insira valores válidos para os lados do triângulo.';
        resultDiv.style.color = 'red';
        return;
    }

    if (side1 + side2 > side3 && side1 + side3 > side2 && side2 + side3 > side1) {
        if (side1 === side2 && side2 === side3) {
            resultDiv.innerText = 'Triângulo Equilátero: todos os lados são iguais.';
        } else if (side1 === side2 || side1 === side3 || side2 === side3) {
            resultDiv.innerText = 'Triângulo Isósceles: dois lados são iguais.';
        } else {
            resultDiv.innerText = 'Triângulo Escaleno: todos os lados são diferentes.';
        }
        resultDiv.style.color = 'green';
    } else {
        resultDiv.innerText = 'Os valores fornecidos não formam um triângulo.';
        resultDiv.style.color = 'red';
    }
});
