// script.js
document.getElementById('menuForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const dish = document.getElementById('dish').value;
    const detailsDiv = document.getElementById('details');
    let details = '';

    switch(dish) {
        case 'pizza':
            details = `
                <img src="https://via.placeholder.com/300x200?text=Pizza" alt="Pizza">
                <p>Pizza: Deliciosa pizza com molho de tomate, queijo e pepperoni.<br>Preço: R$ 30,00</p>
            `;
            break;
        case 'hamburguer':
            details = `
                <img src="https://via.placeholder.com/300x200?text=Hamb%C3%BArguer" alt="Hambúrguer">
                <p>Hambúrguer: Suculento hambúrguer com alface, tomate, queijo e bacon.<br>Preço: R$ 25,00</p>
            `;
            break;
        case 'salada':
            details = `
                <img src="https://via.placeholder.com/300x200?text=Salada" alt="Salada">
                <p>Salada: Salada fresca com alface, tomate, cenoura e molho especial.<br>Preço: R$ 20,00</p>
            `;
            break;
        case 'macarrao':
            details = `
                <img src="https://via.placeholder.com/300x200?text=Macarr%C3%A3o" alt="Macarrão">
                <p>Macarrão: Macarrão ao molho branco com frango e brócolis.<br>Preço: R$ 28,00</p>
            `;
            break;
        case 'sopa':
            details = `
                <img src="https://via.placeholder.com/300x200?text=Sopa" alt="Sopa">
                <p>Sopa: Sopa de legumes e frango, perfeita para os dias frios.<br>Preço: R$ 18,00</p>
            `;
            break;
        case 'sushi':
            details = `
                <img src="https://via.placeholder.com/300x200?text=Sushi" alt="Sushi">
                <p>Sushi: Variedade de sushis frescos com peixe, arroz e algas.<br>Preço: R$ 35,00</p>
            `;
            break;
        default:
            details = 'Por favor, selecione um prato válido.';
            break;
    }

    detailsDiv.innerHTML = details;
    detailsDiv.classList.add('visible');
    document.getElementById('addToCart').classList.remove('hidden');
});

const cart = [];
document.getElementById('addToCart').addEventListener('click', function() {
    const dish = document.getElementById('dish').value;
    let price = 0;
    let itemName = '';

    switch(dish) {
        case 'pizza':
            price = 30;
            itemName = 'Pizza';
            break;
        case 'hamburguer':
            price = 25;
            itemName = 'Hambúrguer';
            break;
        case 'salada':
            price = 20;
            itemName = 'Salada';
            break;
        case 'macarrao':
            price = 28;
            itemName = 'Macarrão';
            break;
        case 'sopa':
            price = 18;
            itemName = 'Sopa';
            break;
        case 'sushi':
            price = 35;
            itemName = 'Sushi';
            break;
        default:
            return;
    }

    cart.push({ itemName, price });
    updateCart();
});

function updateCart() {
    const cartItems = document.getElementById('cartItems');
    const totalPriceElement = document.getElementById('totalPrice');
    cartItems.innerHTML = '';
    let totalPrice = 0;

    cart.forEach(item => {
        const li = document.createElement('li');
        li.innerText = `${item.itemName} - R$ ${item.price},00`;
        cartItems.appendChild(li);
        totalPrice += item.price;
    });

    totalPriceElement.innerText = `Total: R$ ${totalPrice},00`;
    document.getElementById('cart').classList.remove('hidden');
}

document.getElementById('reviewForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const review = document.getElementById('review').value;
    const rating = document.getElementById('rating').value;

    const reviewList = document.getElementById('reviewList');
    const li = document.createElement('li');
    li.innerText = `Nota: ${rating} - ${review}`;
    reviewList.appendChild(li);

    document.getElementById('reviewForm').reset();
});

document.getElementById('dish').addEventListener('change', function() {
    document.getElementById('details').classList.remove('visible');
    document.getElementById('addToCart').classList.add('hidden');
    document.getElementById('reviews').classList.remove('hidden');
    document.getElementById('reviewList').innerHTML = '';
});
