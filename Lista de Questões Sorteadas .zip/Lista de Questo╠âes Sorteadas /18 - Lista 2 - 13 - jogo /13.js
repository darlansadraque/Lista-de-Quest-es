let secretNumber = Math.floor(Math.random() * 100) + 1;
let attempts = 0;

function submitGuess() {
    const userGuess = document.getElementById('guess').value;
    const feedback = document.getElementById('feedback');
    attempts++;

    if (attempts > 10) {
        feedback.textContent = 'Fim do jogo! Suas tentativas acabaram.';
        return;
    }

    if (userGuess == secretNumber) {
        feedback.textContent = `Parabéns! Você acertou o número em ${attempts} tentativas.`;
    } else if (userGuess < secretNumber) {
        feedback.textContent = 'Mais alto! Tente um número maior.';
    } else {
        feedback.textContent = 'Mais baixo! Tente um número menor.';
    }

    if (attempts === 10) {
        feedback.textContent += ' Fim do jogo! O número era ' + secretNumber + '.';
    }
}
