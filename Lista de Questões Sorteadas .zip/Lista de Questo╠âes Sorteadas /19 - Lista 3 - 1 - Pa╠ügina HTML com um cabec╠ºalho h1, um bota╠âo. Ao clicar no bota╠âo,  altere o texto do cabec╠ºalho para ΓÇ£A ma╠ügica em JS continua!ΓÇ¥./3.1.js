document.getElementById('magicButton').addEventListener('click', function() {
    document.getElementById('headerText').textContent = 'A mágica em JS continua!';
});
