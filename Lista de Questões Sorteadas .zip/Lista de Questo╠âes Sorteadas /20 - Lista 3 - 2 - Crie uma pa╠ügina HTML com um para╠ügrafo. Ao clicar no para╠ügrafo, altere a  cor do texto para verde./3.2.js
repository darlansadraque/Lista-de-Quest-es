document.getElementById('paragraphText').addEventListener('click', function() {
    this.style.color = 'green';
});
