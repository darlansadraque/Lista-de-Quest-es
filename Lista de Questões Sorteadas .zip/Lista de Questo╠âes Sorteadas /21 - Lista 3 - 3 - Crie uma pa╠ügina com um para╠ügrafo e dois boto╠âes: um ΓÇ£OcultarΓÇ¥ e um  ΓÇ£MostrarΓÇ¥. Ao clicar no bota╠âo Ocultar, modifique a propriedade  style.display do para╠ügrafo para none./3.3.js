document.getElementById('hideButton').addEventListener('click', function() {
    document.getElementById('paragraphText').style.display = 'none';
});

document.getElementById('showButton').addEventListener('click', function() {
    document.getElementById('paragraphText').style.display = 'block';
});
