function trocarImagem() {
    document.getElementById('imagem').src = '3.4.imagens/adulto.jpg';
    document.getElementById('mensagem').style.display = 'block';
    console.log('Imagem trocada com sucesso!');
}
