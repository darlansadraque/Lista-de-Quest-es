function trocarImagem() {
    document.getElementById('imagem').src = '3.4.imagens/adulto.jpg';
    console.log('Imagem trocada com sucesso!');
}
