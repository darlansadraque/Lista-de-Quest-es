function exibirImagem(src) {
    document.getElementById('displayImage').src = src;
}
