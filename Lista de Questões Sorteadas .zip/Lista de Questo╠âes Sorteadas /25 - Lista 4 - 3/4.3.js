document.getElementById('mediaForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Obtendo os valores dos campos de entrada e convertendo para números de ponto flutuante
    let numero1 = parseFloat(document.getElementById('numero1').value);
    let numero2 = parseFloat(document.getElementById('numero2').value);
    let numero3 = parseFloat(document.getElementById('numero3').value);

    // Calculando a média
    let media = (numero1 + numero2 + numero3) / 3;

    // Formatando a média para duas casas decimais
    let mediaFormatada = media.toFixed(2);

    // Exibindo a média em um alerta
    alert(`A média dos três números é: ${mediaFormatada}`);
});
