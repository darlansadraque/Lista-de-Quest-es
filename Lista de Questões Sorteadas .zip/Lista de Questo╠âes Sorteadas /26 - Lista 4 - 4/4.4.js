// Definindo a função que exibe uma mensagem na tela
function exibirMensagem() {
    alert('Olá! Esta é uma mensagem exibida pela função exibirMensagem.');
}

// Chamando a função para ver o resultado ao carregar a página
exibirMensagem();
