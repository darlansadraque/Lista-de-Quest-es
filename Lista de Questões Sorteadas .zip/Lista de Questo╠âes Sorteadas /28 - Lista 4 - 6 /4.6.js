document.getElementById('quadradoForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Obtendo o valor do campo de entrada
    let numero = parseFloat(document.getElementById('numero').value);

    // Chamando a função para calcular o quadrado
    let resultado = calcularQuadrado(numero);

    // Exibindo o resultado
    document.getElementById('resultado').textContent = `O quadrado de ${numero} é: ${resultado}`;
});

// Função para calcular o quadrado de um número
function calcularQuadrado(num) {
    return num * num;
}
