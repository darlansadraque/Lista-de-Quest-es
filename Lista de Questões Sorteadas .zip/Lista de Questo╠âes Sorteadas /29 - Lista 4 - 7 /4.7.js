// Variável global
let globalVar = "Eu sou uma variável global";

function testarEscopo() {
    // Variável local
    let localVar = "Eu sou uma variável local";
    
    // Acessando a variável global dentro da função
    console.log("Dentro da função testarEscopo:");
    console.log(globalVar);
    
    // Acessando a variável local dentro da função
    console.log(localVar);

    // Exibindo as variáveis na página
    document.getElementById('resultado').textContent = `Dentro da função testarEscopo: \n${globalVar}\n${localVar}`;
}

// Tentando acessar a variável global fora da função
console.log("Fora da função testarEscopo:");
console.log(globalVar);

// Tentando acessar a variável local fora da função (isso causará um erro)
try {
    console.log(localVar);
} catch (error) {
    console.log("Erro ao acessar localVar fora da função:", error.message);
}
