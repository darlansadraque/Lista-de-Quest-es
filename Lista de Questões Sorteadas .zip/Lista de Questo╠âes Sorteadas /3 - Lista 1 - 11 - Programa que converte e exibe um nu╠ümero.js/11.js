let history = [];

function convertAndDisplay() {
    var numberString = document.getElementById('numberInput').value;
    var inputBase = parseInt(document.getElementById('inputBaseSelect').value);
    var outputBase = parseInt(document.getElementById('outputBaseSelect').value);
    var messageElement = document.getElementById('message');

    if (!isValidInput(numberString, inputBase)) {
        messageElement.textContent = 'Por favor, insira um número válido para a base de entrada selecionada.';
        messageElement.style.color = 'red';
        document.getElementById('numberInput').value = '';
        return;
    }

    var decimalValue = parseInt(numberString, inputBase);
    var convertedNumber = decimalValue.toString(outputBase);

    if (isNaN(decimalValue)) {
        messageElement.textContent = 'Conversão falhou. Por favor, verifique sua entrada.';
        messageElement.style.color = 'red';
    } else {
        var outputMessage = `Convertido de base ${inputBase} para base ${outputBase}: ${convertedNumber}`;
        console.log(outputMessage);
        messageElement.textContent = outputMessage;
        messageElement.style.color = 'green';
        updateHistory(numberString, inputBase, outputBase, convertedNumber);
    }

    document.getElementById('numberInput').value = '';
}

function updateHistory(input, inputBase, outputBase, result) {
    history.push({ input, inputBase, outputBase, result });
    displayHistory();
}

function displayHistory() {
    const historyElement = document.getElementById('conversionHistory');
    historyElement.innerHTML = '';
    history.forEach(item => {
        let li = document.createElement('li');
        li.textContent = `Base ${item.inputBase} (${item.input}) → Base ${item.outputBase} (${item.result})`;
        historyElement.appendChild(li);
    });
}

function clearHistory() {
    history = [];
    displayHistory();
}

function exportHistory() {
    const historyText = history.map(h => `Base ${h.inputBase} (${h.input}) → Base ${h.outputBase} (${h.result})`).join('\n');
    const blob = new Blob([historyText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'conversion_history.txt';
    a.click();
    URL.revokeObjectURL(url);
}

function isValidInput(input, base) {
    const baseRegex = {
        10: /^[0-9]+$/,     // Decimal
        2: /^[0-1]+$/,      // Binário
        8: /^[0-7]+$/,      // Octal
        16: /^[0-9A-Fa-f]+$/  // Hexadecimal
    };
    return baseRegex[base].test(input);
}
