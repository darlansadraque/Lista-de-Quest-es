document.addEventListener('DOMContentLoaded', function() {
    // Seleciona o formulário e adiciona um evento de submissão
    document.getElementById('mediaForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Evita o comportamento padrão do formulário

        // Obtém os valores dos campos de entrada
        let numero1 = parseFloat(document.getElementById('numero1').value);
        let numero2 = parseFloat(document.getElementById('numero2').value);

        // Calcula a média dos números
        let media = calcularMedia(numero1, numero2);

        // Exibe a média calculada na página
        exibirResultado(media);
    });
});

// Função para calcular a média de dois números
function calcularMedia(num1, num2) {
    return (num1 + num2) / 2;
}

// Função para exibir o resultado na página
function exibirResultado(media) {
    let mensagem = `A média dos números é: ${media}`;
    document.getElementById('mensagem').innerHTML = mensagem;
}
