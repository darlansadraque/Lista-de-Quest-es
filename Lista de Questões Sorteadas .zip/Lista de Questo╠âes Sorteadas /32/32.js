document.addEventListener('DOMContentLoaded', function() {
    // Variáveis do jogo
    const numeroSecreto = Math.floor(Math.random() * 100) + 1;
    let tentativas = 0;
    const maxTentativas = 10;

    // Seleciona os elementos do DOM
    const form = document.getElementById('guessForm');
    const inputPalpite = document.getElementById('palpite');
    const resultado = document.getElementById('resultado');
    const tentativasElemento = document.getElementById('tentativas');

    // Função para verificar o palpite do usuário
    function verificarPalpite(palpite) {
        tentativas++;
        if (palpite === numeroSecreto) {
            exibirMensagem(`Parabéns! Você acertou o número secreto ${numeroSecreto} em ${tentativas} tentativas.`, true);
        } else if (tentativas >= maxTentativas) {
            exibirMensagem(`Você atingiu o número máximo de tentativas. O número secreto era ${numeroSecreto}.`, true);
        } else if (palpite < numeroSecreto) {
            exibirMensagem(`Errado! O número secreto é maior que ${palpite}.`);
        } else {
            exibirMensagem(`Errado! O número secreto é menor que ${palpite}.`);
        }
        atualizarTentativas();
    }

    // Função para exibir a mensagem de resultado
    function exibirMensagem(mensagem, fimDeJogo = false) {
        resultado.textContent = mensagem;
        if (fimDeJogo) {
            form.removeEventListener('submit', enviarPalpite);
            inputPalpite.disabled = true;
        }
    }

    // Função para atualizar a contagem de tentativas
    function atualizarTentativas() {
        tentativasElemento.textContent = `Tentativas: ${tentativas} de ${maxTentativas}`;
    }

    // Função para enviar o palpite do usuário
    function enviarPalpite(event) {
        event.preventDefault();
        const palpite = parseInt(inputPalpite.value);
        if (!isNaN(palpite)) {
            verificarPalpite(palpite);
            inputPalpite.value = '';
            inputPalpite.focus();
        }
    }

    // Adiciona o evento de submissão ao formulário
    form.addEventListener('submit', enviarPalpite);

    // Inicializa o jogo
    atualizarTentativas();
});
