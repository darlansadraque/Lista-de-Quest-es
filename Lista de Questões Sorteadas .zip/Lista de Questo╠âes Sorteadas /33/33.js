document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('calculatorForm');
    const resultado = document.getElementById('resultado');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Obtém os valores dos campos de entrada
        const numero1 = parseFloat(document.getElementById('numero1').value);
        const numero2 = parseFloat(document.getElementById('numero2').value);
        const operacao = document.getElementById('operacao').value;

        // Variável para armazenar o resultado
        let res;

        // Chama a função apropriada com base na operação selecionada
        switch (operacao) {
            case 'add':
                res = adicionar(numero1, numero2);
                break;
            case 'subtract':
                res = subtrair(numero1, numero2);
                break;
            case 'multiply':
                res = multiplicar(numero1, numero2);
                break;
            case 'divide':
                res = dividir(numero1, numero2);
                break;
            default:
                res = 'Operação inválida';
        }

        // Exibe o resultado
        exibirResultado(res);
    });

    // Função para adicionar dois números
    function adicionar(num1, num2) {
        return num1 + num2;
    }

    // Função para subtrair dois números
    function subtrair(num1, num2) {
        return num1 - num2;
    }

    // Função para multiplicar dois números
    function multiplicar(num1, num2) {
        return num1 * num2;
    }

    // Função para dividir dois números
    function dividir(num1, num2) {
        if (num2 === 0) {
            return 'Erro: Divisão por zero';
        }
        return num1 / num2;
    }

    // Função para exibir o resultado na página
    function exibirResultado(res) {
        resultado.textContent = `Resultado: ${res}`;
    }
});
