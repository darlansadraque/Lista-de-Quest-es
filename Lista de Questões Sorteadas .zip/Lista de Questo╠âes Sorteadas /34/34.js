document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('converterForm');
    const resultado = document.getElementById('resultado');
    const taxaDeCambio = 5.0; // Taxa de câmbio fixa para conversão (exemplo)

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Obtém o valor de entrada
        const valorReal = parseFloat(document.getElementById('valorReal').value);

        // Realiza a conversão
        const valorDolar = converterParaDolar(valorReal, taxaDeCambio);

        // Exibe o resultado
        exibirResultado(valorReal, valorDolar);
    });

    // Função para converter Real para Dólar
    function converterParaDolar(real, taxa) {
        return real / taxa;
    }

    // Função para exibir o resultado na página
    function exibirResultado(real, dolar) {
        resultado.textContent = `R$${real.toFixed(2)} equivalem a $${dolar.toFixed(2)} dólares.`;
    }
});
