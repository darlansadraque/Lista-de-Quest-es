document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('imcForm');
    const resultado = document.getElementById('resultado');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Obtém os valores dos campos de entrada
        const altura = parseFloat(document.getElementById('altura').value);
        const peso = parseFloat(document.getElementById('peso').value);

        // Calcula o IMC
        const imc = calcularIMC(altura, peso);

        // Obtém a categoria do IMC
        const categoria = obterCategoriaIMC(imc);

        // Exibe o resultado
        exibirResultado(imc, categoria);
    });

    // Função para calcular o IMC
    function calcularIMC(altura, peso) {
        return peso / (altura * altura);
    }

    // Função para obter a categoria do IMC
    function obterCategoriaIMC(imc) {
        if (imc < 18.5) {
            return 'Abaixo do peso';
        } else if (imc >= 18.5 && imc < 24.9) {
            return 'Peso normal';
        } else if (imc >= 25 && imc < 29.9) {
            return 'Sobrepeso';
        } else {
            return 'Obesidade';
        }
    }

    // Função para exibir o resultado na página
    function exibirResultado(imc, categoria) {
        resultado.textContent = `Seu IMC é ${imc.toFixed(2)}. Categoria: ${categoria}.`;
    }
});
