document.addEventListener('DOMContentLoaded', function() {
    // Criação do objeto aluno
    const aluno = {
        nome: 'João Silva',
        idade: 20,
        curso: 'Engenharia da Computação',
        notas: {
            matematica: 8.5,
            fisica: 9.0,
            quimica: 7.5
        }
    };

    // Função para calcular a média das notas
    function calcularMedia(notas) {
        const valores = Object.values(notas);
        const soma = valores.reduce((acc, nota) => acc + nota, 0);
        return soma / valores.length;
    }

    // Função para exibir os dados do aluno na página
    function exibirDadosAluno(aluno) {
        const dadosAlunoDiv = document.getElementById('dadosAluno');
        const media = calcularMedia(aluno.notas);
        dadosAlunoDiv.innerHTML = `
            <p><strong>Nome:</strong> ${aluno.nome}</p>
            <p><strong>Idade:</strong> ${aluno.idade}</p>
            <p><strong>Curso:</strong> ${aluno.curso}</p>
            <p><strong>Notas:</strong></p>
            <ul>
                <li>Matemática: ${aluno.notas.matematica}</li>
                <li>Física: ${aluno.notas.fisica}</li>
                <li>Química: ${aluno.notas.quimica}</li>
            </ul>
            <p><strong>Média das Notas:</strong> ${media.toFixed(2)}</p>
        `;
    }

    // Exibir os dados do aluno na página
    exibirDadosAluno(aluno);
});
