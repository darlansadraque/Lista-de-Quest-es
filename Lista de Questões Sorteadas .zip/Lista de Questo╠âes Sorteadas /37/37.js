document.addEventListener('DOMContentLoaded', function() {
    // Criação do objeto carro
    const carro = {
        marca: 'Toyota',
        modelo: 'Corolla',
        ano: 2021
    };

    // Função para exibir a marca do carro na página
    function exibirMarcaCarro(carro) {
        const marcaCarroDiv = document.getElementById('marcaCarro');
        marcaCarroDiv.textContent = `Marca do carro: ${carro.marca}`;
    }

    // Exibir a marca do carro na página
    exibirMarcaCarro(carro);
});
