document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('livroForm');
    const resultado = document.getElementById('resultado');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Criação do objeto livro
        const livro = {
            titulo: document.getElementById('titulo').value,
            autor: document.getElementById('autor').value,
            anoPublicacao: parseInt(document.getElementById('anoPublicacao').value, 10)
        };

        // Função para exibir o título e o autor do livro
        function exibirLivro(livro) {
            resultado.textContent = `Título: ${livro.titulo}, Autor: ${livro.autor}`;
        }

        // Exibir o título e o autor do livro
        exibirLivro(livro);
    });
});
