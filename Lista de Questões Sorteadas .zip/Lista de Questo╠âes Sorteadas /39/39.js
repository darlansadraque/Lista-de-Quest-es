document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('produtoForm');
    const resultado = document.getElementById('resultado');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Criação do objeto produto
        const produto = {
            nome: document.getElementById('nome').value,
            preco: parseFloat(document.getElementById('preco').value),
            quantidade: parseInt(document.getElementById('quantidade').value, 10)
        };

        // Função para calcular o valor total do estoque
        function calcularValorEstoque(produto) {
            return produto.preco * produto.quantidade;
        }

        // Calcular o valor do estoque
        const valorEstoque = calcularValorEstoque(produto);

        // Função para exibir o resultado na página
        function exibirResultado(produto, valorEstoque) {
            resultado.textContent = `Produto: ${produto.nome}, Valor Total do Estoque: R$${valorEstoque.toFixed(2)}`;
        }

        // Exibir o valor do estoque
        exibirResultado(produto, valorEstoque);
    });
});
