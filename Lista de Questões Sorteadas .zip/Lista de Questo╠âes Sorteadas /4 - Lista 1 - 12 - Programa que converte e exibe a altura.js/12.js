function converterParaPesEpolegadas(metros) {
    const alturaPes = metros * 3.28084;
    const pesInteiros = Math.floor(alturaPes);
    const polegadas = Math.round((alturaPes - pesInteiros) * 12);
    return { pes: pesInteiros, polegadas: polegadas };
}

function converterParaCentimetros(metros) {
    return metros * 100;
}

function converterParaMilimetros(metros) {
    return metros * 1000;
}

function verificarSelecao() {
    const exibirPesPolegadas = document.getElementById('pesPolegadas').checked;
    const exibirCentimetros = document.getElementById('centimetros').checked;
    const exibirMilimetros = document.getElementById('milimetros').checked;
    
    if (!exibirPesPolegadas && !exibirCentimetros && !exibirMilimetros) {
        alert(i18next.t('alert.select_unit'));
    } else {
        converterAltura();
    }
}

function converterAltura() {
    const alturaInput = document.getElementById('alturaMetros').value;
    const alturaMetros = parseFloat(alturaInput);
    const resultadoDiv = document.getElementById('resultado');

    if (!isNaN(alturaMetros) && alturaMetros > 0) {
        let resultadoTexto = `${i18next.t('result.your_height_is')} ${alturaMetros} ${i18next.t('result.meters')}`;
        if (document.getElementById('pesPolegadas').checked) {
            const { pes, polegadas } = converterParaPesEpolegadas(alturaMetros);
            resultadoTexto += `, ${pes} ${i18next.t('result.feet')} ${polegadas} ${i18next.t('result.inches')}`;
        }
        if (document.getElementById('centimetros').checked) {
            const centimetros = converterParaCentimetros(alturaMetros);
            resultadoTexto += `, ${centimetros} ${i18next.t('result.centimeters')}`;
        }
        if (document.getElementById('milimetros').checked) {
            const milimetros = converterParaMilimetros(alturaMetros);
            resultadoTexto += `, ${milimetros} ${i18next.t('result.millimeters')}`;
        }
        resultadoTexto += '.';
        resultadoDiv.textContent = resultadoTexto;
        resultadoDiv.className = 'resultado success';
        
        localStorage.setItem('ultimaConversao', resultadoTexto);
        document.getElementById('ultimaConversao').textContent = "Última conversão: " + localStorage.getItem('ultimaConversao');
    } else {
        resultadoDiv.textContent = i18next.t('result.invalid_input');
        resultadoDiv.className = 'resultado error';
    }
}

function limparConversao() {
    localStorage.removeItem('ultimaConversao');
    document.getElementById('ultimaConversao').textContent = "";
}

// Configuração inicial do i18next
i18next.init({
    lng: 'pt', // Idioma inicial
    resources: {
        en: {
            translation: {
                "title": "Height Converter",
                "units": {
                    "feet_inches": "Feet/Inches",
                    "centimeters": "Centimeters",
                    "millimeters": "Millimeters"
                },
                "buttons": {
                    "convert": "Convert",
                    "clear": "Clear Last Conversion"
                },
                "input": {
                    "placeholder": "Enter your height in meters"
                },
                "alert": {
                    "select_unit": "Please select at least one unit for conversion."
                },
                "result": {
                    "your_height_is": "Your height is",
                    "meters": "meters",
                    "feet": "feet",
                    "inches": "inches",
                    "centimeters": "centimeters",
                    "millimeters": "millimeters",
                    "invalid_input": "Invalid input. Please enter a valid and positive number."
                }
            }
        },
        pt: {
            translation: {
                "title": "Conversor de Altura",
                "units": {
                    "feet_inches": "Pés/Polegadas",
                    "centimeters": "Centímetros",
                    "millimeters": "Milímetros"
                },
                "buttons": {
                    "convert": "Converter",
                    "clear": "Limpar Última Conversão"
                },
                "input": {
                    "placeholder": "Digite sua altura em metros"
                },
                "alert": {
                    "select_unit": "Por favor, selecione pelo menos uma unidade para conversão."
                },
                "result": {
                    "your_height_is": "Sua altura é",
                    "meters": "metros",
                    "feet": "pés",
                    "inches": "polegadas",
                    "centimeters": "centímetros",
                    "millimeters": "milímetros",
                    "invalid_input": "Entrada inválida. Por favor, digite um número válido e positivo."
                }
            }
        },
        es: {
            translation: {
                "title": "Conversor de Altura",
                "units": {
                    "feet_inches": "Pies/Pulgadas",
                    "centimeters": "Centímetros",
                    "millimeters": "Milímetros"
                },
                "buttons": {
                    "convert": "Convertir",
                    "clear": "Limpiar última conversión"
                },
                "input": {
                    "placeholder": "Introduce tu altura en metros"
                },
                "alert": {
                    "select_unit": "Por favor, seleccione al menos una unidad para la conversión."
                },
                "result": {
                    "your_height_is": "Tu altura es",
                    "meters": "metros",
                    "feet": "pies",
                    "inches": "pulgadas",
                    "centimeters": "centímetros",
                    "millimeters": "milímetros",
                    "invalid_input": "Entrada no válida. Por favor, introduzca un número válido y positivo."
                }
            }
        },
        fr: {
            translation: {
                "title": "Convertisseur de Taille",
                "units": {
                    "feet_inches": "Pieds/Pouces",
                    "centimeters": "Centimètres",
                    "millimeters": "Millimètres"
                },
                "buttons": {
                    "convert": "Convertir",
                    "clear": "Effacer la dernière conversion"
                },
                "input": {
                    "placeholder": "Entrez votre taille en mètres"
                },
                "alert": {
                    "select_unit": "Veuillez sélectionner au moins une unité pour la conversion."
                },
                "result": {
                    "your_height_is": "Votre taille est",
                    "meters": "mètres",
                    "feet": "pieds",
                    "inches": "pouces",
                    "centimeters": "centimètres",
                    "millimeters": "millimètres",
                    "invalid_input": "Entrée invalide. Veuillez entrer un numéro valide et positif."
                }
            }
        }
    }
}, function(err, t) {
    // Inicialização da tradução do HTML
    updateContent();
});

function updateContent() {
    document.querySelectorAll('[data-i18n]').forEach(function(element) {
        element.innerHTML = i18next.t(element.getAttribute('data-i18n'));
    });
    document.getElementById('alturaMetros').placeholder = i18next.t('input.placeholder');
}

document.getElementById('languageSelector').addEventListener('change', function(event) {
    i18next.changeLanguage(event.target.value, updateContent);
});

window.onload = function() {
    const ultimaConversao = localStorage.getItem('ultimaConversao');
    if (ultimaConversao) {
        document.getElementById('ultimaConversao').textContent = "Última conversão: " + ultimaConversao;
    }
}
