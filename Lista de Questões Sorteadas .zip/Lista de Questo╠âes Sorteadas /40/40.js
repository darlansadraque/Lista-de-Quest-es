// Adiciona um evento de submissão ao formulário
document.getElementById('nameForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o comportamento padrão do formulário de recarregar a página

    // Obtém o valor do campo de entrada
    let nome = document.getElementById('nome').value;

    // Calcula o número de caracteres na string
    let numeroDeCaracteres = nome.length;

    // Cria uma mensagem para exibir o número de caracteres
    let mensagem = `O nome "${nome}" tem ${numeroDeCaracteres} caracteres.`;

    // Exibe a mensagem no parágrafo com id "mensagem"
    document.getElementById('mensagem').textContent = mensagem;

    // Também imprime a mensagem no console para verificação
    console.log(mensagem);
});
