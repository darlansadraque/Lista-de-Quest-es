// Adiciona um evento de submissão ao formulário
document.getElementById('nameForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o comportamento padrão do formulário de recarregar a página

    // Obtém o valor do campo de entrada
    let nomeCompleto = document.getElementById('nome').value;

    // Chama a função para extrair o primeiro e último nome
    exibirPrimeiroEUltimoNome(nomeCompleto);
});

// Função para extrair e exibir o primeiro e último nome
function exibirPrimeiroEUltimoNome(nome) {
    // Divide o nome completo em partes
    let partesDoNome = nome.trim().split(' ');

    // Extrai o primeiro e o último nome
    let primeiroNome = partesDoNome[0];
    let ultimoNome = partesDoNome[partesDoNome.length - 1];

    // Cria uma mensagem para exibir o primeiro e último nome
    let mensagem = `Primeiro nome: ${primeiroNome}, Último nome: ${ultimoNome}`;

    // Exibe a mensagem no parágrafo com id "mensagem"
    document.getElementById('mensagem').textContent = mensagem;

    // Também imprime a mensagem no console para verificação
    console.log(mensagem);
}
