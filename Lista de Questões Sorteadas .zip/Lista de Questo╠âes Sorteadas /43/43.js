// Adiciona um evento de submissão ao formulário
document.getElementById('phraseForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o comportamento padrão do formulário de recarregar a página

    // Obtém o valor do campo de entrada
    let frase = document.getElementById('frase').value;

    // Converte a frase para letras maiúsculas usando toUpperCase()
    let fraseMaiuscula = frase.toUpperCase();

    // Cria uma mensagem para exibir a frase em maiúsculas
    let mensagem = `Frase em maiúsculas: ${fraseMaiuscula}`;

    // Exibe a mensagem no parágrafo com id "mensagem"
    document.getElementById('mensagem').textContent = mensagem;

    // Também imprime a mensagem no console para verificação
    console.log(mensagem);
});
