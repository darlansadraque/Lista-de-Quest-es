// Adiciona um evento de submissão ao formulário
document.getElementById('moviesForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o comportamento padrão do formulário de recarregar a página

    // Cria um array para armazenar os nomes dos filmes
    let filmes = [];

    // Obtém os valores dos campos de entrada e armazena no array
    for (let i = 1; i <= 5; i++) {
        let filme = document.getElementById(`filme${i}`).value;
        filmes.push(filme);
    }

    // Exibe cada filme no console usando um laço for tradicional
    for (let i = 0; i < filmes.length; i++) {
        console.log(`Filme ${i + 1}: ${filmes[i]}`);
    }

    // Cria uma mensagem para exibir na página
    let mensagem = "Os filmes foram registrados. Confira o console para mais detalhes.";
    document.getElementById('mensagem').textContent = mensagem;
});
