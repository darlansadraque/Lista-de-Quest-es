// Módulo para gerenciar o banco de dados de usuários
const UserDatabase = (function() {
    // Lista privada para armazenar os dados dos usuários
    const users = [];

    // Função para adicionar um novo usuário
    function addUser(name, email, password) {
        const user = { name, email, password };
        users.push(user);
        console.log(`Usuário adicionado: ${name}`);
    }

    // Função para remover um usuário pelo email
    function removeUser(email) {
        const index = users.findIndex(user => user.email === email);
        if (index !== -1) {
            const removedUser = users.splice(index, 1);
            console.log(`Usuário removido: ${removedUser[0].name}`);
        } else {
            console.log(`Usuário com email ${email} não encontrado.`);
        }
    }

    // Função para atualizar as informações de um usuário pelo email
    function updateUser(email, newName, newEmail, newPassword) {
        const user = users.find(user => user.email === email);
        if (user) {
            user.name = newName !== undefined ? newName : user.name;
            user.email = newEmail !== undefined ? newEmail : user.email;
            user.password = newPassword !== undefined ? newPassword : user.password;
            console.log(`Usuário atualizado: ${user.name}`);
        } else {
            console.log(`Usuário com email ${email} não encontrado.`);
        }
    }

    // Função para listar todos os usuários (apenas para fins de teste)
    function listUsers() {
        console.log('Lista de usuários:');
        users.forEach(user => {
            console.log(`Nome: ${user.name}, Email: ${user.email}`);
        });
    }

    // Retorna apenas as funções públicas
    return {
        addUser,
        removeUser,
        updateUser,
        listUsers // Esta função é para teste e pode ser removida em produção
    };
})();

// Exemplo de uso do módulo UserDatabase
UserDatabase.addUser('Alice', 'alice@example.com', 'password123');
UserDatabase.addUser('Bob', 'bob@example.com', 'password456');
UserDatabase.listUsers();

UserDatabase.updateUser('bob@example.com', 'Bobby', 'bob.new@example.com', 'newpassword456');
UserDatabase.listUsers();

UserDatabase.removeUser('alice@example.com');
UserDatabase.listUsers();
