// Adiciona um evento que espera o DOM ser carregado
document.addEventListener('DOMContentLoaded', function() {
    // Seleciona o elemento da caixa pelo ID
    const colorBox = document.getElementById('colorBox');

    // Adiciona um evento de mouseover para mudar a cor da caixa para vermelho
    colorBox.addEventListener('mouseover', function() {
        colorBox.style.backgroundColor = 'red';
    });

    // Adiciona um evento de mouseout para mudar a cor da caixa de volta para azul
    colorBox.addEventListener('mouseout', function() {
        colorBox.style.backgroundColor = 'blue';
    });
});
