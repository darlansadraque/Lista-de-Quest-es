// Adiciona um evento de submissão ao formulário
document.getElementById('loanForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o comportamento padrão do formulário de recarregar a página

    // Obtém os valores dos campos de entrada
    let idade = parseInt(document.getElementById('idade').value);
    let renda = parseFloat(document.getElementById('renda').value);

    // Verifica a elegibilidade para o empréstimo
    let elegivel = verificarElegibilidade(idade, renda);

    // Cria uma mensagem para exibir o resultado
    let mensagem = elegivel ? 'Você é elegível para o empréstimo.' : 'Você não é elegível para o empréstimo.';

    // Exibe a mensagem no parágrafo com id "mensagem"
    document.getElementById('mensagem').textContent = mensagem;

    // Também imprime a mensagem no console para verificação
    console.log(mensagem);
});

// Função para verificar a elegibilidade para o empréstimo
function verificarElegibilidade(idade, renda) {
    // Critérios de elegibilidade
    const rendaMinima = 3000;
    const idadeMinima = 18;
    const idadeMaxima = 65;

    // Verifica se a renda mensal é maior que R$ 3000 e se a idade está entre 18 e 65 anos
    return renda > rendaMinima && idade >= idadeMinima && idade <= idadeMaxima;
}
