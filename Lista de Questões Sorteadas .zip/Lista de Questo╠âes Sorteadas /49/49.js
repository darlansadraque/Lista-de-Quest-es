// Adiciona um evento de submissão ao formulário
document.getElementById('welcomeForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o comportamento padrão do formulário de recarregar a página

    // Obtém o valor do campo de entrada
    let nome = document.getElementById('nome').value;

    // Cria a mensagem de boas-vindas
    let mensagem = `Bem-vindo, ${nome}!`;

    // Exibe a mensagem no parágrafo com id "mensagem" usando innerHTML
    document.getElementById('mensagem').innerHTML = mensagem;
});
