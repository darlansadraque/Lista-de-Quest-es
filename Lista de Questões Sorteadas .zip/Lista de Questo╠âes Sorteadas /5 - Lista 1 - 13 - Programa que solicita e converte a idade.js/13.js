function mostrarIdade() {
    const inputIdade = document.getElementById('idadeInput').value;
    const idade = Number(inputIdade);

    if (!isNaN(idade)) {
        console.log(`Sua idade é: ${idade}`);
        alert(`Sua idade é: ${idade}`);
    } else {
        console.log("Por favor, insira um número válido.");
        alert("Por favor, insira um número válido.");
    }
}
