// Função para somar dois números
function somar(num1, num2) {
    return num1 + num2;
}

// Função para subtrair dois números
function subtrair(num1, num2) {
    return num1 - num2;
}

// Função para multiplicar dois números
function multiplicar(num1, num2) {
    return num1 * num2;
}

// Função para dividir dois números
function dividir(num1, num2) {
    return num1 / num2;
}
// Função para exibir uma mensagem no parágrafo com id "mensagem"
function exibirMensagem(mensagem) {
    document.getElementById('mensagem').innerHTML = mensagem;
}
// Adiciona um evento de submissão ao formulário
document.getElementById('exampleForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o comportamento padrão do formulário de recarregar a página

    // Obtém os valores dos campos de entrada
    let numero1 = parseFloat(document.getElementById('numero1').value);
    let numero2 = parseFloat(document.getElementById('numero2').value);

    // Realiza os cálculos
    let soma = somar(numero1, numero2);
    let subtracao = subtrair(numero1, numero2);
    let multiplicacao = multiplicar(numero1, numero2);
    let divisao = dividir(numero1, numero2);

    // Cria a mensagem de resultado
    let mensagem = `
        Resultados:<br>
        Soma: ${soma}<br>
        Subtração: ${subtracao}<br>
        Multiplicação: ${multiplicacao}<br>
        Divisão: ${divisao}
    `;

    // Exibe a mensagem de resultado
    exibirMensagem(mensagem);
});
