// Adiciona um evento de submissão ao formulário
document.getElementById('inputForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o comportamento padrão do formulário de recarregar a página

    // Obtém os valores dos campos de entrada
    let frase = document.getElementById('frase').value;
    let palavras = document.getElementById('palavras').value.split(','); // Converte a string em um array de palavras

    // Remove espaços em branco extras nas palavras
    palavras = palavras.map(palavra => palavra.trim());

    // Verifica se cada palavra está presente na frase
    let resultados = palavras.map(palavra => {
        if (frase.includes(palavra)) {
            return `"${palavra}" está presente na frase.`;
        } else {
            return `"${palavra}" não está presente na frase.`;
        }
    });

    // Junta os resultados em uma string
    let mensagem = resultados.join('<br>');

    // Exibe a mensagem de resultado
    document.getElementById('resultado').innerHTML = mensagem;
});
