function verificarParidade() { /* 
1 - Obtém o valor do campo de entrada numero e o elemento resultado para exibição.
2 - Verifica se o campo está vazio e define a mensagem e cor do texto apropriadas.
3 - Converte o valor de entrada em um inteiro e verifica se é par ou ímpar, atualizando o texto e a cor do resultado.
*/
    var numero = document.getElementById('numero').value;/* 
    1 - O var numero Declara uma variável numero que armazena o valor atual inserido no campo de entrada com o ID numero. 
    2 - O método getElementById é usado para encontrar um elemento pelo seu ID no DOM (Document Object Model) 
    3 - value obtém o valor desse elemento.*/

    var resultado = document.getElementById('resultado');/*Declara uma variável resultado que armazena a referência ao elemento <p> com o ID resultado, onde o resultado da verificação (par ou ímpar) será exibido. */

    if (!numero) { /*Verifica se o valor de numero é falso. Em JavaScript, valores vazios, como uma string vazia (que seria o caso se nenhum número fosse digitado), são considerados falsos. */
        resultado.textContent = 'Por favor, insira um número válido.'; /*Define o texto do elemento resultado para informar ao usuário que ele deve inserir um número válido. */
        resultado.style.color = 'red';/*Muda a cor do texto de resultado para vermelho, indicando um aviso ou erro. */
        return; /*Sai da função, impedindo que qualquer código subsequente seja executado se o valor for inválido. */
    }

    numero = parseInt(numero);/*Converte o valor da string numero para um inteiro. Se o valor contiver caracteres que não são dígitos após o primeiro conjunto de dígitos, eles serão ignorados. Isso garante que mesmo se a entrada contiver espaços ou outros caracteres após os números, o valor ainda será corretamente convertido para um número inteiro. */

    if (numero % 2 === 0) { /**Usa o operador módulo (%) para determinar se o número é par. Se o número dividido por 2 tiver resto zero, então é par.*/
        resultado.textContent = `O número ${numero} é par.`;/*O número ${numero} é par.;: Se o número for par, esta linha atualiza o texto de resultado para informar que o número é par. */
        resultado.style.color = 'green';/*Muda a cor do texto para verde, indicando que o número é par e a operação foi bem-sucedida. */
    } else {/*A cláusula else captura todos os casos em que o número não é par (ou seja, é ímpar). */
        resultado.textContent = `O número ${numero} é ímpar.`; /*O número ${numero} é ímpar.;: Atualiza o texto de resultado para informar que o número é ímpar. */
        resultado.style.color = 'blue';/*Muda a cor do texto para azul, diferenciando a saída visual para números ímpares. */
    }
}
