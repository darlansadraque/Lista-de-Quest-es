document.getElementById('numberForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const num1 = document.getElementById('num1').value.trim();
    const num2 = document.getElementById('num2').value.trim();
    const num3 = document.getElementById('num3').value.trim();

    if (isNaN(num1) || isNaN(num2) || isNaN(num3) || num1 === '' || num2 === '' || num3 === '') {
        document.getElementById('result').textContent = 'Por favor, insira valores numéricos válidos.';
        document.getElementById('result').style.color = 'red';
    } else {
        const number1 = parseFloat(num1);
        const number2 = parseFloat(num2);
        const number3 = parseFloat(num3);

        const maxNum = Math.max(number1, number2, number3);

        document.getElementById('result').textContent = `O maior número é: ${maxNum}`;
        document.getElementById('result').style.color = 'green';
    }
});

document.getElementById('toggleTheme').addEventListener('click', function() {
    if (document.documentElement.getAttribute('data-theme') === 'dark') {
        document.documentElement.setAttribute('data-theme', 'light');
    } else {
        document.documentElement.setAttribute('data-theme', 'dark');
    }
});
