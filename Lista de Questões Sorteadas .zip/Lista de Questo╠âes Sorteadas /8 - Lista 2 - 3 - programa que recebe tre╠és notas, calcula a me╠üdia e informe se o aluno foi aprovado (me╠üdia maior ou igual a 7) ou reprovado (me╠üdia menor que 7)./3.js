document.addEventListener('DOMContentLoaded', () => {
    const gradeForm = document.getElementById('gradeForm');
    const resultDiv = document.getElementById('result');
    const resetFormButton = document.getElementById('resetForm');
    const lightThemeButton = document.getElementById('lightTheme');
    const darkThemeButton = document.getElementById('darkTheme');
    const blueThemeButton = document.getElementById('blueTheme');

    const THEME_KEY = 'selectedTheme';

    function validateGrade(grade) {
        return !isNaN(grade) && grade >= 0 && grade <= 10;
    }

    function calculateAverage(nota1, nota2, nota3) {
        return (nota1 + nota2 + nota3) / 3;
    }

    function displayResult(media) {
        const status = media >= 7 ? 'Aprovado' : 'Reprovado';
        resultDiv.textContent = `Média: ${media.toFixed(2)} - ${status}`;
    }

    function displayError(message) {
        resultDiv.innerHTML = `<span id="error">${message}</span>`;
    }

    function resetForm() {
        gradeForm.reset();
        resultDiv.textContent = '';
    }

    function switchTheme(theme) {
        document.body.className = theme;
        localStorage.setItem(THEME_KEY, theme);
    }

    function loadSavedTheme() {
        const savedTheme = localStorage.getItem(THEME_KEY);
        if (savedTheme) {
            document.body.className = savedTheme;
        }
    }

    gradeForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const nota1 = parseFloat(document.getElementById('nota1').value);
        const nota2 = parseFloat(document.getElementById('nota2').value);
        const nota3 = parseFloat(document.getElementById('nota3').value);

        if (!validateGrade(nota1)) {
            displayError('Nota 1 inválida. Insira um valor entre 0 e 10.');
            return;
        }
        if (!validateGrade(nota2)) {
            displayError('Nota 2 inválida. Insira um valor entre 0 e 10.');
            return;
        }
        if (!validateGrade(nota3)) {
            displayError('Nota 3 inválida. Insira um valor entre 0 e 10.');
            return;
        }

        const media = calculateAverage(nota1, nota2, nota3);
        displayResult(media);
    });

    resetFormButton.addEventListener('click', resetForm);

    lightThemeButton.addEventListener('click', () => switchTheme('light-theme'));
    darkThemeButton.addEventListener('click', () => switchTheme('dark-theme'));
    blueThemeButton.addEventListener('click', () => switchTheme('blue-theme'));

    loadSavedTheme();
});
