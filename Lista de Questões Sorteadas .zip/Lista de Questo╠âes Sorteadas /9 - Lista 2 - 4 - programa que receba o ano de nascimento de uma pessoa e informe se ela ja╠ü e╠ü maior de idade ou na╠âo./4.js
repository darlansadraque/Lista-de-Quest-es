document.addEventListener('DOMContentLoaded', () => {
    const ageForm = document.getElementById('ageForm');
    const resultDiv = document.getElementById('result');
    const resetFormButton = document.getElementById('resetForm');
    const lightThemeButton = document.getElementById('lightTheme');
    const darkThemeButton = document.getElementById('darkTheme');
    const blueThemeButton = document.getElementById('blueTheme');

    const THEME_KEY = 'selectedTheme';

    function getCurrentYear() {
        return new Date().getFullYear();
    }

    function validateYear(year) {
        const currentYear = getCurrentYear();
        return !isNaN(year) && year > 1900 && year <= currentYear;
    }

    function checkMajority(birthYear) {
        const currentYear = getCurrentYear();
        const age = currentYear - birthYear;
        return age >= 18 ? 'Maior de idade' : 'Menor de idade';
    }

    function displayResult(message) {
        resultDiv.textContent = message;
    }

    function displayError(message) {
        resultDiv.innerHTML = `<span id="error">${message}</span>`;
    }

    function resetForm() {
        ageForm.reset();
        resultDiv.textContent = '';
    }

    function switchTheme(theme) {
        document.body.className = theme;
        localStorage.setItem(THEME_KEY, theme);
    }

    function loadSavedTheme() {
        const savedTheme = localStorage.getItem(THEME_KEY);
        if (savedTheme) {
            document.body.className = savedTheme;
        }
    }

    ageForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const birthYear = parseInt(document.getElementById('birthYear').value);

        if (!validateYear(birthYear)) {
            displayError('Ano de nascimento inválido. Insira um valor válido.');
            return;
        }

        const result = checkMajority(birthYear);
        displayResult(result);
    });

    resetFormButton.addEventListener('click', resetForm);

    lightThemeButton.addEventListener('click', () => switchTheme('light-theme'));
    darkThemeButton.addEventListener('click', () => switchTheme('dark-theme'));
    blueThemeButton.addEventListener('click', () => switchTheme('blue-theme'));

    loadSavedTheme();
});
